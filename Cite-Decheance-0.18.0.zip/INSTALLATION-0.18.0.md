# La Cité de la Déchéance — 0.18.0-dev

Minecraft Java 1.20.1, Java 17, Forge 47.3.0 ou plus récent dans la série 47 et GeckoLib 4.4.9 ou plus récent dans la série 4 sont nécessaires. Ces dépendances sont installées séparément.

Fermez le jeu et le serveur, sauvegardez le monde, puis remplacez le précédent JAR de la Cité dans `mods/` par `citedecheance-0.18.0-dev.jar`, côté client et côté serveur. Gardez un seul JAR de la Cité et utilisez la même version des deux côtés.

Les nouveaux mondes utilisent le profil de génération 11 : chaque cité prévoit 30 cours de Ramoneur et 10 cimetières de Fossoyeur dans les quartiers pauvres. Le placement évite les structures protégées et peut fournir moins d'arènes si elles se chevauchent ou si une graine très contrainte manque d'espace. Les mondes déjà créés conservent leur profil et leurs constructions ; les nouvelles arènes nécessitent un nouveau monde. Voir `docs/POOR-ARENAS-0.18.md` dans le dépôt.

Chaque Fossoyeur possède un coffre de première victoire propre à son arène ; son état est sauvegardé. Le coffre peut attendre qu'une position autorisée et chargée soit disponible. Les sauvegardes de chunks et des données de cité ne constituent pas une transaction commune en cas d'arrêt brutal ; conservez des sauvegardes de votre monde.

Les deux boss ont des attaques à distance, des animations enrichies et une musique de combat. Les nouveaux ensembles d'armure de boss dépassent les caractéristiques de la Netherite ; le balai et la pelle possèdent chacun un pouvoir au clic droit. Les coffres de Fossoyeur offrent notamment de l'équipement de boss, des objets enchantés et des ressources précieuses. Les coffres déjà remplis ne sont pas relancés.

Les potions appliquent réellement l'effet vanilla Force V à VIII ; Force VIII dure 25 secondes par défaut et sa probabilité reste de 0,15 % par tirage éligible. Le réglage client `particleQuality` conserve `0 = désactivé`, `1 = réduit`, `2 = complet` et `3 = minimal`, sans changer les dégâts. Les secousses de caméra restent réglables.

Les contrôles de ressources et les tests serveur ne remplacent pas une vérification du rendu des modèles, de l'écoute, de l'équilibrage et des performances avec des joueurs réels.

Pour appliquer les réglages de population et de difficulté à une installation existante : `python install_challenge_config.py "/chemin/du/profil/Minecraft"`. L'option `--dry-run` montre les changements ; l'outil sauvegarde les fichiers existants avant modification.
