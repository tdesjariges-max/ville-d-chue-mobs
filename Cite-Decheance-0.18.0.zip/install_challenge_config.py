#!/usr/bin/env python3
"""Install the challenge preset into an explicitly selected Minecraft directory.

Run with Minecraft/server stopped. Existing config files are backed up before
replacement; unrelated settings and comments are retained. No world or entity
NBT is edited. Only newly created entities reliably receive the new attributes.
Requires Python 3.11+ (tomllib). Use --self-test for temporary-directory tests.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import os
from pathlib import Path
import re
import shutil
import stat
import tempfile
import tomllib
import unittest

SPECIES = {
    "fantassin_dechu": (120.0, 16.0), "arbaletrier_dechu": (90.0, 13.0),
    "rampant": (80.0, 13.0), "grimpeur": (100.0, 15.0),
    "sapeur": (70.0, 8.0), "fouisseur": (180.0, 20.0),
    "porte_bouclier": (200.0, 18.0), "porte_corruption": (145.0, 14.0),
}
PRESETS = {
    "citedecheance-fallen.toml": {
        ("species", species): {"health": health, "attackDamage": damage}
        for species, (health, damage) in SPECIES.items()
    },
    "citedecheance-population.toml": {
        (): {"activeOrdinaryCap": 1536, "nearbyOrdinaryCap": 128},
    },
    "citedecheance-siege.toml": {
        ("siege",): {"sapperPlayerDamage": 6.0, "sapperCreatureDamage": 12.0},
    },
    "citedecheance-common.toml": {
        ("combat",): {"eboueurHealth": 1600.0, "dechuHealth": 80.0,
                      "dechuDamage": 14.0, "wispImpactDamage": 10.0},
    },
}
ASSIGNMENT = re.compile(r'''^([ \t]*(?:[A-Za-z0-9_-]+|"[^"\\]*"|'[^']*')[ \t]*=[ \t]*)(.*)$''')


def without_comment(value: str) -> tuple[str, str]:
    """Split a TOML line outside single/double quoted strings."""
    quote = None
    escaped = False
    for index, char in enumerate(value):
        if quote == '"' and escaped:
            escaped = False
        elif quote == '"' and char == "\\":
            escaped = True
        elif quote:
            if char == quote:
                quote = None
        elif char in "\"'":
            quote = char
        elif char == "#":
            return value[:index], value[index:]
    return value, ""


def table_path(header: str) -> tuple[str, ...] | None:
    if header.startswith("[["):
        return None  # Unrelated arrays of tables are preserved, never patched.
    marker = "__challenge_config_section_marker__"
    tree = tomllib.loads(header + "\n" + marker + " = true\n")
    path = []
    while marker not in tree:
        if len(tree) != 1:
            raise ValueError("Unsupported TOML table header")
        key, tree = next(iter(tree.items()))
        path.append(key)
    return tuple(path)


def expected_document(original: dict, preset: dict) -> dict:
    expected = deepcopy(original)
    for section, values in preset.items():
        table = expected
        for key in section:
            table = table.setdefault(key, {})
            if not isinstance(table, dict):
                raise ValueError("Configuration section is not a table: " + ".".join(section))
        table.update(values)
    return expected


def patch_config(raw: bytes, preset: dict) -> bytes:
    """Patch regular Forge TOML scalar tables, failing closed on other layouts."""
    bom = raw.startswith(b"\xef\xbb\xbf")
    text = raw.decode("utf-8-sig")
    original = tomllib.loads(text)
    expected = expected_document(original, preset)
    if original == expected:
        return raw
    newline = "\r\n" if "\r\n" in text else "\n"
    output = []
    current = ()
    visited = set()
    seen = set()

    def append_line(line: str) -> None:
        if output and not output[-1].endswith(("\n", "\r")):
            output[-1] += newline
        output.append(line + newline)

    def finish_section() -> None:
        if current not in preset:
            return
        visited.add(current)
        for key, value in preset[current].items():
            if (current, key) not in seen:
                append_line(f"{key} = {value}")
                seen.add((current, key))

    for line in text.splitlines(keepends=True):
        body = line.rstrip("\r\n")
        ending = line[len(body):]
        uncommented, _ = without_comment(body)
        header = uncommented.strip()
        if header.startswith("["):
            finish_section()
            current = table_path(header)
        match = ASSIGNMENT.match(body)
        if current in preset and match:
            prefix, remaining = match.groups()
            key_source = prefix.split("=", 1)[0].strip()
            key = next(iter(tomllib.loads(key_source + " = 0")))
            if key in preset[current]:
                value_source, comment = without_comment(remaining)
                trailing = value_source[len(value_source.rstrip()):]
                output.append(prefix + str(preset[current][key]) + trailing + comment + ending)
                seen.add((current, key))
                continue
        output.append(line)
    finish_section()
    for section, values in preset.items():
        if section in visited:
            continue
        if output and output[-1].strip():
            append_line("")
        if section:
            append_line("[" + ".".join(section) + "]")
        for key, value in values.items():
            append_line(f"{key} = {value}")
    result = "".join(output)
    # This also detects unsupported inline tables, multiline string lookalikes,
    # or dotted assignments. No file is written unless only intended values change.
    if tomllib.loads(result) != expected:
        raise ValueError("Unsupported TOML layout; no configuration files were changed")
    return (b"\xef\xbb\xbf" if bom else b"") + result.encode("utf-8")


def install(game_dir: Path, dry_run: bool = False) -> list[tuple[Path, Path | None]]:
    game_dir = game_dir.expanduser().resolve()
    if not game_dir.is_dir():
        raise ValueError("The Minecraft directory must already exist: " + str(game_dir))
    config_dir = game_dir / "config"
    if config_dir.is_symlink() or config_dir.exists() and not config_dir.is_dir():
        raise ValueError("Refusing a linked or non-directory config path")
    planned = []
    # Preflight every file before writing or backing up any configuration.
    for filename, preset in PRESETS.items():
        path = config_dir / filename
        if path.is_symlink() or path.exists() and not path.is_file():
            raise ValueError("Refusing a linked or non-regular config file: " + str(path))
        old = path.read_bytes() if path.exists() else b""
        updated = patch_config(old, preset)
        if updated != old:
            planned.append((path, updated))
    if dry_run:
        return [(path, None) for path, _ in planned]
    if planned:
        config_dir.mkdir(exist_ok=True)
    results = []
    for path, updated in planned:
        backup = None
        if path.exists():
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
            backup = path.with_name(path.name + ".challenge-backup-" + stamp)
            # Exclusive creation prevents overwriting an earlier backup.
            with backup.open("xb") as stream:
                stream.write(path.read_bytes())
            shutil.copystat(path, backup)
        mode = stat.S_IMODE(path.stat().st_mode) if path.exists() else 0o600
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=config_dir, prefix=".challenge-", delete=False) as stream:
                temporary = Path(stream.name)
                stream.write(updated)
                stream.flush()
                os.fsync(stream.fileno())
            temporary.chmod(mode)
            os.replace(temporary, path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
        results.append((path, backup))
    return results


class InstallerTests(unittest.TestCase):
    def test_preserves_comments_unknown_settings_and_crlf(self):
        original = (b"# custom config\r\nactiveOrdinaryCap = 256  # limit\r\n"
                    b"nearbyOrdinaryCap=20\r\ncustom = 'a#b'\r\n"
                    b"[other]\r\nactiveOrdinaryCap = 9\r\n")
        updated = patch_config(original, PRESETS["citedecheance-population.toml"])
        self.assertIn(b"activeOrdinaryCap = 1536  # limit\r\n", updated)
        self.assertIn(b"custom = 'a#b'\r\n[other]\r\nactiveOrdinaryCap = 9\r\n", updated)
        self.assertEqual(patch_config(updated, PRESETS["citedecheance-population.toml"]), updated)

    def test_adds_missing_keys_in_existing_and_missing_sections(self):
        original = b'[species."fantassin_dechu"]\nhealth = 52.0\ncustom = 9\n[other]\nflag = true'
        updated = patch_config(original, PRESETS["citedecheance-fallen.toml"])
        parsed = tomllib.loads(updated.decode())
        self.assertEqual(parsed["species"]["fantassin_dechu"]["custom"], 9)
        for species, (health, damage) in SPECIES.items():
            self.assertEqual(parsed["species"][species]["health"], health)
            self.assertEqual(parsed["species"][species]["attackDamage"], damage)
        self.assertTrue(parsed["other"]["flag"])

    def test_backup_matches_original_and_second_run_is_noop(self):
        with tempfile.TemporaryDirectory() as directory:
            game = Path(directory)
            config = game / "config"
            config.mkdir()
            file = config / "citedecheance-common.toml"
            original = b"[combat]\ndechuHealth = 40.0\n# user notes\ncustom = 3\n"
            file.write_bytes(original)
            results = install(game)
            self.assertEqual(len(results), 4)
            backup = next(backup for path, backup in results if path == file)
            self.assertEqual(backup.read_bytes(), original)
            self.assertEqual(install(game), [])
            self.assertEqual(tomllib.loads(file.read_text())["combat"]["custom"], 3)

    def test_invalid_file_prevents_all_writes(self):
        with tempfile.TemporaryDirectory() as directory:
            game = Path(directory)
            config = game / "config"
            config.mkdir()
            bad = config / "citedecheance-siege.toml"
            bad.write_bytes(b"[broken\n")
            with self.assertRaises(tomllib.TOMLDecodeError):
                install(game)
            self.assertEqual(list(config.iterdir()), [bad])
            self.assertEqual(bad.read_bytes(), b"[broken\n")

    def test_dry_run_never_creates_config(self):
        with tempfile.TemporaryDirectory() as directory:
            game = Path(directory)
            self.assertEqual(len(install(game, dry_run=True)), 4)
            self.assertFalse((game / "config").exists())

    def test_rejects_linked_file_without_touching_target(self):
        with tempfile.TemporaryDirectory() as directory:
            game = Path(directory)
            config = game / "config"
            config.mkdir()
            target = game / "user.toml"
            target.write_bytes(b"x=1\n")
            (config / "citedecheance-fallen.toml").symlink_to(target)
            with self.assertRaises(ValueError):
                install(game)
            self.assertEqual(target.read_bytes(), b"x=1\n")
            self.assertEqual(len(list(config.iterdir())), 1)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("game_dir", nargs="?", type=Path,
                        help="Existing .minecraft or server directory; must be supplied explicitly")
    parser.add_argument("--dry-run", action="store_true", help="List changes without writing files")
    parser.add_argument("--self-test", action="store_true", help="Run tests in temporary directories")
    args = parser.parse_args()
    if args.self_test:
        if args.game_dir is not None or args.dry_run:
            parser.error("--self-test cannot be combined with an installation")
        return 0 if unittest.TextTestRunner(verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(InstallerTests)).wasSuccessful() else 1
    if args.game_dir is None:
        parser.error("game_dir is required; no default Minecraft directory is assumed")
    try:
        results = install(args.game_dir, args.dry_run)
    except (OSError, ValueError) as error:
        parser.exit(1, f"Installation stopped: {error}\n")
    for path, backup in results:
        print(("Would update " if args.dry_run else "Updated ") + str(path))
        if backup:
            print("  Backup: " + str(backup))
    if not results:
        print("Challenge configuration is already installed.")
    print("Existing entity NBT was not changed; restart Minecraft/server before testing newly spawned mobs.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
